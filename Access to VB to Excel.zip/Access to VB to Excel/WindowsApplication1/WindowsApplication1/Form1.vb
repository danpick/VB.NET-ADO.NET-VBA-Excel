﻿Imports Microsoft.Office.Interop 'requires reference to Microsoft Excel Object Library
Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'reference point:
        'http://vb.net-informations.com/excel-2007/vb.net_excel_create_chart.htm

        'declare variables for database connections etc.
        Dim sProvider As String
        Dim sSource As String
        Dim sSQL As String
        Dim dsData As New DataSet
        Dim da As OleDb.OleDbDataAdapter
        Dim con As New OleDb.OleDbConnection

        'declare Excel automation objects
        Dim objBooks As Excel.Workbooks
        Dim objSheets As Excel.Sheets
        Dim objSheet As Excel._Worksheet
        Dim objApp As Excel.Application
        Dim objBook As Excel._Workbook

        'connect to database
        sProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"
        sSource = "Data Source = " & Application.StartupPath & "\Project.accdb"
        con.ConnectionString = sProvider & sSource
        con.Open()

        'get data from database
        sSQL = "SELECT tblData.niPersonID, "
        sSQL = sSQL & "tblData.tFirstName, "
        sSQL = sSQL & "tblData.tSecondName, "
        sSQL = sSQL & "tblData.iValue "
        sSQL = sSQL & "FROM tblData"
        da = New OleDb.OleDbDataAdapter(sSQL, con)
        da.Fill(dsData, "AllData")

        'instantiate new instance of Excel
        objApp = New Excel.Application()
        objBooks = objApp.Workbooks
        objBook = objBooks.Add
        objSheets = objBook.Worksheets
        objSheet = objSheets(1)

        'iterate through database dataset, inserting it into Excel
        Dim sFullName As String
        For i = 0 To dsData.Tables("AllData").Rows.Count - 1
            sFullName = dsData.Tables("AllData").Rows(i).Item("tFirstName") & " " & dsData.Tables("AllData").Rows(i).Item("tSecondName")
            objSheet.Cells(i + 1, 1) = sFullName
            objSheet.Cells(i + 1, 2) = dsData.Tables("AllData").Rows(i).Item("iValue")
        Next i

        'select range in Excel
        objSheet.Range(objSheet.Cells(1, 1), objSheet.Cells(dsData.Tables("AllData").Rows.Count, 2)).Select()

        'create chart
        objSheet.Shapes.AddChart.Select()
        objApp.ActiveChart.ChartType = Excel.XlChartType.xlColumnClustered
        objApp.ActiveChart.Location(Excel.XlChartLocation.xlLocationAsNewSheet, "My Graph")
        objApp.ActiveChart.ChartArea.Select()
        objApp.ActiveChart.Legend.Select()
        objApp.Selection.Delete()

        'display and save Excel
        objApp.UserControl = True
        objApp.DisplayAlerts = False
        objBook.SaveAs(Application.StartupPath & "\" & Now.Year & Format(Now.Month, "00") & Format(Now.Day, "00") & " " & Format(Now.Hour, "00") & Format(Now.Minute, "00") & ".xlsx")
        objApp.Visible = True

        'kill background objects
        objSheet = Nothing
        objSheets = Nothing
        objBook = Nothing
        objBooks = Nothing

    End Sub
End Class
