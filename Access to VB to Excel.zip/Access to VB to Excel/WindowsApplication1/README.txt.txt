VB.NET prototype of reading data from Access database using ADO.NET, and then sending this data to Excel using embedded VBA to create chart output. Small prototype, but I can code VBA to a very high standard.

Any questions - danpick77@gmail.com